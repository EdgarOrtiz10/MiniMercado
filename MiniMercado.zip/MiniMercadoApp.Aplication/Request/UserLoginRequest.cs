﻿namespace MiniMercadoApp.Api.Request
{
    public class UserLoginRequest
    {
        public string IdUser { get; set; }    
        public string Pass { get; set; }
        public string Active { get; set; }

    }
}
