﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MiniMercadoApp.Application.Requests
{
    public class DeleteProveedoresRequest
    {
        public int Id { get; set; }
    }
}
