﻿namespace MiniMercado.Application.Requests

{
    public class GetProductosByIdRequest
    {
        public int Id { get; set; }
    }
}
