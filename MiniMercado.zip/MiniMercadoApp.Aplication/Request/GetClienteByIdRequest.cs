﻿namespace MiniMercado.Application.Requests

{
    public class GetClienteByIdRequest
    {
        public int Id { get; set; }
    }
}
