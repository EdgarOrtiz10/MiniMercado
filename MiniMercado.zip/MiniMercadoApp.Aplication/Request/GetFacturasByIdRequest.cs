﻿namespace MiniMercado.Application.Requests

{
    public class GetFacturasByIdRequest
    {
        public int Id { get; set; }
    }
}
