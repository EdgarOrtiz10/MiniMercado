﻿namespace MiniMercado.Application.Requests

{
    public class GetVentasByIdRequest
    {
        public int Id { get; set; }
    }
}
