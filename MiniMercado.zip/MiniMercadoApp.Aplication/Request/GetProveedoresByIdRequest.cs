﻿namespace MiniMercado.Application.Requests
{
    public class GetProveedoresByIdRequest
    {
        public int Id { get; set; }
    }
}
