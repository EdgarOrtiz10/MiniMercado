﻿namespace MiniMercado.Application.Requests

{
    public class GetCategoriaByIdRequest
    {
        public int Id { get; set; }
    }
}
