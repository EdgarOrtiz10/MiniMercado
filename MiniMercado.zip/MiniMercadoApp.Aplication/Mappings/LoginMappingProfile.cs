﻿using AutoMapper;
using MiniMercadoApp.Domain.Entities;
/*
namespace MiniMercadoApp.Aplication.Mappings
{
    public class LoginMappingProfile : Profile
    {
        
        public LoginMappingProfile()
        {
            CreateMap<CreateLoginRequest, Login>();
            CreateMap<Login, CreateLoginRequest>();

            CreateMap<UpdateLoginRequest, Login>();
            CreateMap<Login, UpdateLoginRequest>();
        }
    }
}
*/